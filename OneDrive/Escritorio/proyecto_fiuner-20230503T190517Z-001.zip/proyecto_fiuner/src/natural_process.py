from bs4 import BeautifulSoup 
import csv
import spacy
import pandas as pd
# Cargar el modelo pre-entrenado de Spacy en español
nlp = spacy.load('es_core_news_sm')
# Cargar el texto de la oferta laboral desde un archivo
#with open('ofertas-2021-02-08', 'r') as f:
#   text = f.read()
with open(r"C:\Users\enzor\Desktop\ofertas-2021-02-08.html","r", encoding="utf8") as f:
    # leer el archivo HTML
    html = f.read()
    # analizar el HTML con BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')
    # extraer el texto del HTML
    text = soup.get_text()
# Procesar el texto con el modelo de Spacy
doc = nlp(text)

# Imprimir las entidades nombradas
# for ent in doc.ents:
#     print(ent.text, ent.start_char, ent.end_char, ent.label_)
entities = []
for ent in doc.ents:
    entities.append((ent.text, ent.label_))
df = pd.DataFrame(entities, columns=['Entidad', 'Tipo'])
df.to_csv('entidades.csv', index=False)